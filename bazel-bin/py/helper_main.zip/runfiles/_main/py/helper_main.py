def greet(name: str) -> str:
    return f"Hello, {name}! This is Python running inside Bazel."
